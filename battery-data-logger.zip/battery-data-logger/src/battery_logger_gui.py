"""
Laptop Battery Data Logger
--------------------------
A GUI-based laptop battery monitor and logger.

Features:
- Live battery status
- Plug-in / plug-out event detection
- CPU, RAM, and disk usage logging
- CSV logging
- Excel export
- Real-time graph visualization
- Low battery alert

Author: Your Name / Company
License: MIT
"""

from __future__ import annotations

import csv
import os
import platform
import subprocess
import sys
from dataclasses import dataclass, asdict
from datetime import datetime
from pathlib import Path
from typing import Optional, Union, List

import psutil
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure

try:
    import pandas as pd
except ImportError:  # Excel export will show a friendly error if pandas is missing
    pd = None


BASE_DIR = Path(__file__).resolve().parent.parent
LOG_DIR = BASE_DIR / "logs"
EXPORT_DIR = BASE_DIR / "exports"
LOG_FILE = LOG_DIR / "battery_log.csv"
EVENT_FILE = LOG_DIR / "battery_events.csv"

LOG_DIR.mkdir(exist_ok=True)
EXPORT_DIR.mkdir(exist_ok=True)


@dataclass
class BatterySample:
    timestamp: str
    battery_percent: int
    battery_state: str
    plugged: str
    seconds_left: Union[int, str]
    time_left: str
    cpu_percent: float
    ram_percent: float
    disk_percent: float
    os_name: str


class BatteryLoggerApp:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("Laptop Battery Data Logger")
        self.root.geometry("1100x720")
        self.root.minsize(980, 640)

        self.is_logging = False
        self.job_id: Optional[str] = None
        self.previous_plugged: Optional[bool] = None
        self.low_battery_alert_sent = False

        self.time_points: List[str] = []
        self.battery_points: List[int] = []
        self.cpu_points: List[float] = []
        self.ram_points: List[float] = []
        self.max_graph_points = 50

        self.interval_var = tk.IntVar(value=10)
        self.low_alert_var = tk.IntVar(value=20)

        self.percent_var = tk.StringVar(value="— %")
        self.state_var = tk.StringVar(value="—")
        self.plugged_var = tk.StringVar(value="—")
        self.time_left_var = tk.StringVar(value="—")
        self.cpu_var = tk.StringVar(value="— %")
        self.ram_var = tk.StringVar(value="— %")
        self.disk_var = tk.StringVar(value="— %")
        self.status_var = tk.StringVar(value="Ready")

        self.setup_style()
        self.ensure_csv_headers()
        self.build_ui()
        self.refresh_once()

    def setup_style(self) -> None:
        style = ttk.Style()
        if "clam" in style.theme_names():
            style.theme_use("clam")
        style.configure("Title.TLabel", font=("Segoe UI", 18, "bold"))
        style.configure("CardTitle.TLabel", font=("Segoe UI", 11, "bold"))
        style.configure("Value.TLabel", font=("Segoe UI", 13, "bold"))

    def build_ui(self) -> None:
        wrapper = ttk.Frame(self.root, padding=12)
        wrapper.pack(fill="both", expand=True)

        header = ttk.Frame(wrapper)
        header.pack(fill="x")
        ttk.Label(header, text="Laptop Battery Data Logger", style="Title.TLabel").pack(side="left")
        ttk.Label(header, textvariable=self.status_var).pack(side="right")

        controls = ttk.LabelFrame(wrapper, text="Controls", padding=10)
        controls.pack(fill="x", pady=(12, 8))

        ttk.Label(controls, text="Log Interval (seconds):").pack(side="left")
        ttk.Spinbox(controls, from_=2, to=3600, textvariable=self.interval_var, width=7).pack(side="left", padx=(6, 16))

        ttk.Label(controls, text="Low Battery Alert (%):").pack(side="left")
        ttk.Spinbox(controls, from_=5, to=80, textvariable=self.low_alert_var, width=7).pack(side="left", padx=(6, 16))

        self.start_btn = ttk.Button(controls, text="Start Logging", command=self.start_logging)
        self.start_btn.pack(side="left", padx=4)
        self.stop_btn = ttk.Button(controls, text="Stop", command=self.stop_logging, state="disabled")
        self.stop_btn.pack(side="left", padx=4)
        ttk.Button(controls, text="Refresh Now", command=self.refresh_once).pack(side="left", padx=4)
        ttk.Button(controls, text="Export Excel", command=self.export_excel).pack(side="left", padx=4)
        ttk.Button(controls, text="Open Logs Folder", command=lambda: self.open_path(LOG_DIR)).pack(side="left", padx=4)
        ttk.Button(controls, text="Clear Table", command=self.clear_table).pack(side="right", padx=4)

        dashboard = ttk.Frame(wrapper)
        dashboard.pack(fill="x", pady=(0, 8))

        self.progress = ttk.Progressbar(dashboard, orient="horizontal", mode="determinate", length=260)
        self.make_card(dashboard, "Battery", self.percent_var, 0, 0, self.progress)
        self.make_card(dashboard, "State", self.state_var, 0, 1)
        self.make_card(dashboard, "Plug Status", self.plugged_var, 0, 2)
        self.make_card(dashboard, "Time Left", self.time_left_var, 0, 3)
        self.make_card(dashboard, "CPU Usage", self.cpu_var, 1, 0)
        self.make_card(dashboard, "RAM Usage", self.ram_var, 1, 1)
        self.make_card(dashboard, "Disk Usage", self.disk_var, 1, 2)

        for col in range(4):
            dashboard.grid_columnconfigure(col, weight=1)

        main_area = ttk.PanedWindow(wrapper, orient="horizontal")
        main_area.pack(fill="both", expand=True)

        table_frame = ttk.LabelFrame(main_area, text="Live Log Table", padding=8)
        graph_frame = ttk.LabelFrame(main_area, text="Real-time Graph", padding=8)
        main_area.add(table_frame, weight=3)
        main_area.add(graph_frame, weight=2)

        columns = (
            "timestamp", "battery", "state", "plugged", "time_left", "cpu", "ram", "disk"
        )
        self.tree = ttk.Treeview(table_frame, columns=columns, show="headings", height=18)
        headings = {
            "timestamp": "Timestamp",
            "battery": "Battery %",
            "state": "State",
            "plugged": "Plugged",
            "time_left": "Time Left",
            "cpu": "CPU %",
            "ram": "RAM %",
            "disk": "Disk %",
        }
        widths = {
            "timestamp": 160,
            "battery": 80,
            "state": 110,
            "plugged": 90,
            "time_left": 90,
            "cpu": 70,
            "ram": 70,
            "disk": 70,
        }
        for col in columns:
            self.tree.heading(col, text=headings[col])
            self.tree.column(col, width=widths[col], anchor="center")

        self.tree.pack(side="left", fill="both", expand=True)
        y_scroll = ttk.Scrollbar(table_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=y_scroll.set)
        y_scroll.pack(side="right", fill="y")

        self.figure = Figure(figsize=(5, 4), dpi=100)
        self.ax = self.figure.add_subplot(111)
        self.ax.set_title("Battery / CPU / RAM")
        self.ax.set_xlabel("Samples")
        self.ax.set_ylabel("Percent")
        self.ax.set_ylim(0, 100)
        self.canvas = FigureCanvasTkAgg(self.figure, master=graph_frame)
        self.canvas.get_tk_widget().pack(fill="both", expand=True)

        footer = ttk.Frame(wrapper)
        footer.pack(fill="x", pady=(8, 0))
        ttk.Label(footer, text=f"CSV Log: {LOG_FILE}").pack(side="left")
        ttk.Button(footer, text="Exit", command=self.on_exit).pack(side="right")

    def make_card(self, parent: ttk.Frame, title: str, variable: tk.StringVar, row: int, col: int,
                  widget: Optional[ttk.Widget] = None) -> None:
        card = ttk.LabelFrame(parent, text=title, padding=10)
        card.grid(row=row, column=col, padx=5, pady=5, sticky="nsew")
        ttk.Label(card, textvariable=variable, style="Value.TLabel").pack(anchor="w")
        if widget is not None:
            widget.pack(fill="x", pady=(8, 0))

    def ensure_csv_headers(self) -> None:
        if not LOG_FILE.exists():
            with LOG_FILE.open("w", newline="", encoding="utf-8") as file:
                writer = csv.writer(file)
                writer.writerow([
                    "timestamp", "battery_percent", "battery_state", "plugged",
                    "seconds_left", "time_left", "cpu_percent", "ram_percent",
                    "disk_percent", "os_name"
                ])

        if not EVENT_FILE.exists():
            with EVENT_FILE.open("w", newline="", encoding="utf-8") as file:
                writer = csv.writer(file)
                writer.writerow(["timestamp", "event", "battery_percent"])

    def read_sample(self) -> Optional[BatterySample]:
        battery = psutil.sensors_battery()
        if battery is None:
            return None

        percent = int(round(battery.percent))
        plugged_bool = bool(battery.power_plugged)

        if percent >= 100 and plugged_bool:
            state = "Full / Plugged"
        elif plugged_bool:
            state = "Charging"
        else:
            state = "Discharging"

        if battery.secsleft in (psutil.POWER_TIME_UNLIMITED, psutil.POWER_TIME_UNKNOWN, None):
            seconds_left: Union[int, str] = "-"
        else:
            seconds_left = int(battery.secsleft)

        return BatterySample(
            timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            battery_percent=percent,
            battery_state=state,
            plugged="Yes" if plugged_bool else "No",
            seconds_left=seconds_left,
            time_left=self.format_seconds(seconds_left),
            cpu_percent=round(psutil.cpu_percent(interval=None), 1),
            ram_percent=round(psutil.virtual_memory().percent, 1),
            disk_percent=round(psutil.disk_usage(str(Path.home())).percent, 1),
            os_name=f"{platform.system()} {platform.release()}",
        )

    @staticmethod
    def format_seconds(value: Union[int, str]) -> str:
        if value == "-":
            return "—"
        seconds = int(value)
        hours, remainder = divmod(seconds, 3600)
        minutes, sec = divmod(remainder, 60)
        return f"{hours:02d}:{minutes:02d}:{sec:02d}"

    def apply_sample_to_ui(self, sample: BatterySample) -> None:
        self.percent_var.set(f"{sample.battery_percent}%")
        self.state_var.set(sample.battery_state)
        self.plugged_var.set(sample.plugged)
        self.time_left_var.set(sample.time_left)
        self.cpu_var.set(f"{sample.cpu_percent}%")
        self.ram_var.set(f"{sample.ram_percent}%")
        self.disk_var.set(f"{sample.disk_percent}%")
        self.progress["value"] = sample.battery_percent

        self.tree.insert("", "end", values=(
            sample.timestamp,
            f"{sample.battery_percent}%",
            sample.battery_state,
            sample.plugged,
            sample.time_left,
            f"{sample.cpu_percent}%",
            f"{sample.ram_percent}%",
            f"{sample.disk_percent}%",
        ))
        self.tree.yview_moveto(1.0)

        self.update_graph(sample)

    def update_graph(self, sample: BatterySample) -> None:
        self.time_points.append(sample.timestamp[-8:])
        self.battery_points.append(sample.battery_percent)
        self.cpu_points.append(sample.cpu_percent)
        self.ram_points.append(sample.ram_percent)

        self.time_points = self.time_points[-self.max_graph_points:]
        self.battery_points = self.battery_points[-self.max_graph_points:]
        self.cpu_points = self.cpu_points[-self.max_graph_points:]
        self.ram_points = self.ram_points[-self.max_graph_points:]

        x_values = list(range(len(self.time_points)))
        self.ax.clear()
        self.ax.plot(x_values, self.battery_points, label="Battery %")
        self.ax.plot(x_values, self.cpu_points, label="CPU %")
        self.ax.plot(x_values, self.ram_points, label="RAM %")
        self.ax.set_title("Battery / CPU / RAM Usage")
        self.ax.set_xlabel("Recent Samples")
        self.ax.set_ylabel("Percent")
        self.ax.set_ylim(0, 100)
        self.ax.grid(True, alpha=0.3)
        self.ax.legend(loc="upper right")
        self.figure.tight_layout()
        self.canvas.draw_idle()

    def append_log(self, sample: BatterySample) -> None:
        with LOG_FILE.open("a", newline="", encoding="utf-8") as file:
            writer = csv.DictWriter(file, fieldnames=list(asdict(sample).keys()))
            writer.writerow(asdict(sample))

    def append_event(self, event: str, battery_percent: int) -> None:
        with EVENT_FILE.open("a", newline="", encoding="utf-8") as file:
            writer = csv.writer(file)
            writer.writerow([datetime.now().strftime("%Y-%m-%d %H:%M:%S"), event, battery_percent])
        self.status_var.set(event)

    def detect_events(self, sample: BatterySample) -> None:
        plugged_now = sample.plugged == "Yes"
        if self.previous_plugged is None:
            self.previous_plugged = plugged_now
        elif plugged_now != self.previous_plugged:
            event = "Charger Plugged In" if plugged_now else "Charger Plugged Out"
            self.append_event(event, sample.battery_percent)
            self.previous_plugged = plugged_now

        low_level = int(self.low_alert_var.get())
        if sample.battery_percent <= low_level and not plugged_now and not self.low_battery_alert_sent:
            self.low_battery_alert_sent = True
            self.append_event(f"Low Battery Alert: {sample.battery_percent}%", sample.battery_percent)
            messagebox.showwarning("Low Battery", f"Battery is low: {sample.battery_percent}%")

        if sample.battery_percent > low_level + 5:
            self.low_battery_alert_sent = False

    def log_once(self) -> None:
        sample = self.read_sample()
        if sample is None:
            messagebox.showerror("Battery Not Found", "Battery information is not available on this system.")
            self.stop_logging()
            return

        self.apply_sample_to_ui(sample)
        self.append_log(sample)
        self.detect_events(sample)
        self.status_var.set(f"Last sample saved: {sample.timestamp}")

        if self.is_logging:
            delay = max(1000, int(self.interval_var.get()) * 1000)
            self.job_id = self.root.after(delay, self.log_once)

    def refresh_once(self) -> None:
        sample = self.read_sample()
        if sample is None:
            self.status_var.set("Battery information not available")
            return
        self.apply_sample_to_ui(sample)
        self.detect_events(sample)
        self.status_var.set(f"Refreshed: {sample.timestamp}")

    def start_logging(self) -> None:
        try:
            interval = int(self.interval_var.get())
            if interval < 2:
                raise ValueError
        except ValueError:
            messagebox.showerror("Invalid Interval", "Please enter an interval of 2 seconds or more.")
            return

        self.is_logging = True
        self.start_btn.config(state="disabled")
        self.stop_btn.config(state="normal")
        self.status_var.set("Logging started")
        self.log_once()

    def stop_logging(self) -> None:
        self.is_logging = False
        if self.job_id is not None:
            try:
                self.root.after_cancel(self.job_id)
            except Exception:
                pass
            self.job_id = None
        self.start_btn.config(state="normal")
        self.stop_btn.config(state="disabled")
        self.status_var.set("Logging stopped")

    def export_excel(self) -> None:
        if pd is None:
            messagebox.showerror("Missing Library", "Please install pandas and openpyxl:\n\npip install pandas openpyxl")
            return

        if not LOG_FILE.exists():
            messagebox.showinfo("No Logs", "No battery log file found yet.")
            return

        default_name = f"battery_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
        save_path = filedialog.asksaveasfilename(
            initialdir=EXPORT_DIR,
            initialfile=default_name,
            defaultextension=".xlsx",
            filetypes=[("Excel Workbook", "*.xlsx")],
        )
        if not save_path:
            return

        log_df = pd.read_csv(LOG_FILE)
        event_df = pd.read_csv(EVENT_FILE) if EVENT_FILE.exists() else pd.DataFrame()

        with pd.ExcelWriter(save_path, engine="openpyxl") as writer:
            log_df.to_excel(writer, sheet_name="Battery Logs", index=False)
            event_df.to_excel(writer, sheet_name="Plug Events", index=False)

        messagebox.showinfo("Export Complete", f"Excel report saved:\n{save_path}")

    def clear_table(self) -> None:
        for item in self.tree.get_children():
            self.tree.delete(item)

    @staticmethod
    def open_path(path: Path) -> None:
        try:
            if sys.platform.startswith("win"):
                os.startfile(path)  # type: ignore[attr-defined]
            elif sys.platform == "darwin":
                subprocess.run(["open", str(path)], check=False)
            else:
                subprocess.run(["xdg-open", str(path)], check=False)
        except Exception as exc:
            messagebox.showerror("Open Folder", f"Could not open folder:\n{exc}")

    def on_exit(self) -> None:
        self.stop_logging()
        self.root.destroy()


def main() -> None:
    root = tk.Tk()
    app = BatteryLoggerApp(root)
    root.protocol("WM_DELETE_WINDOW", app.on_exit)
    root.mainloop()


if __name__ == "__main__":
    main()
